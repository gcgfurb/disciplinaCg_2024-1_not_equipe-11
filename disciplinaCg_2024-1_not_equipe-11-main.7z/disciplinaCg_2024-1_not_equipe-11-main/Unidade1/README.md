# Atividades 1

Nota: 10,0  
[x] Ana Carolina da Silva  
[x] Kaue Reblin  
[x] Rodrigo Kapulka Franco

## Assunto: "Luva de Dados (Data Glove) - Impressoras 3D - Blender  

[Slides.pdf](Slides.pdf)  

O Blender é o Blender  
Filmes, assisti alguns .. gostei do Sintel  
Usamos muito na UFRGS para projetos. Usamos em projetos no LDTT. Tem até ferramentas melhores, mas é um coringa muito bom.  

Data Glove  
Evoluímos na detecção dos gestos das mãos, mas ainda "engatinhamos" para sensação de tato.  
Para Realidade Virtual, explorar os sentidos é muito importante .. imersão.  
1977 -> 27 anos  

Impressão 3D  
Pensei que ira popularizar mais, mas ok, tivemos avanços  
Subtrativa e Aditiva  ... refrativa, Shopping .. cristal  
Temos algumas impressoras 3D na FURB, uma na S-427 XYZ-Prossessing  
Um TCC orientado do Miguel fez uma impressora de peças recicladas  
Impressão de órgãos humanos  
